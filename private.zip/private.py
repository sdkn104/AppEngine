
project_id = "proven-mystery-220011"
project_app = "sadakane"  # appEngine address -> https://(project_id).appspot.com/(project_app)/...
IFTTT_key = "uoVHdqccPNfLG8UbUR6Al"

